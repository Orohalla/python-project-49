### Hexlet tests and linter status:
[![Actions Status](https://github.com/Orohalla/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Orohalla/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/ccd1acbb19602e7e9c2f/maintainability)](https://codeclimate.com/github/Orohalla/python-project-49/maintainability)